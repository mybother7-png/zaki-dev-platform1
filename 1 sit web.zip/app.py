from flask import Flask, request, send_file
import yt_dlp
import os

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    message = ""

    if request.method == "POST":
        service = request.form.get("service")

        # ===== تفعيل البوت =====
        if service == "bot":
            name = request.form["name"]
            ff_id = request.form["ff_id"]

            with open("players.txt", "a", encoding="utf-8") as f:
                f.write(f"Name: {name} | ID: {ff_id}\n")

            message = "✅ تم إرسال بياناتك – سيتم تفعيل البوت قريبًا"

        # ===== تحميل أغاني (MP3) =====
        elif service == "music":
            url = request.form.get("music_url")
            try:
                ydl_opts = {
                    'format': 'bestaudio/best',
                    'outtmpl': 'downloads/%(title)s.%(ext)s',
                    'postprocessors': [{
                        'key': 'FFmpegExtractAudio',
                        'preferredcodec': 'mp3',
                        'preferredquality': '192',
                    }],
                }
                os.makedirs("downloads", exist_ok=True)
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url)
                    filename = ydl.prepare_filename(info)
                    filename = os.path.splitext(filename)[0] + ".mp3"
                return send_file(filename, as_attachment=True)
            except Exception as e:
                message = f"❌ خطأ: {e}"

        # ===== تحميل فيديوهات (MP4) =====
        elif service == "video":
            url = request.form.get("video_url")
            try:
                ydl_opts = {
                    'format': 'best',
                    'outtmpl': 'downloads/%(title)s.%(ext)s'
                }
                os.makedirs("downloads", exist_ok=True)
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url)
                    filename = ydl.prepare_filename(info)
                return send_file(filename, as_attachment=True)
            except Exception as e:
                message = f"❌ خطأ: {e}"

    # ===== الواجهة =====
    return f'''
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ZAKI DEV | Multi Services</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap');
body {{
    margin: 0;
    background: radial-gradient(circle at top, #0b0015, #000);
    font-family: 'Orbitron', sans-serif;
    color: white;
}}
.container {{
    width: 900px;
    margin: auto;
    margin-top: 60px;
}}
header {{
    text-align: center;
    margin-bottom: 40px;
}}
header h1 {{
    font-size: 42px;
    color: #b388ff;
    text-shadow: 0 0 20px #7f00ff;
}}
header p {{
    color: #8fdfff;
}}
.services {{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 25px;
}}
.card {{
    background: rgba(10,0,20,0.85);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 0 25px #7f00ff;
    transition: 0.3s;
}}
.card:hover {{
    transform: translateY(-10px);
    box-shadow: 0 0 45px #00eaff;
}}
.card h2 {{
    text-align: center;
    color: #00eaff;
}}
input {{
    width: 100%;
    padding: 12px;
    margin-top: 15px;
    border-radius: 10px;
    border: none;
    background: #0b0015;
    color: #00eaff;
}}
button {{
    margin-top: 20px;
    width: 100%;
    padding: 12px;
    border-radius: 25px;
    border: none;
    background: linear-gradient(90deg, #7f00ff, #00eaff);
    font-size: 15px;
    cursor: pointer;
}}
.message {{
    text-align: center;
    margin-top: 30px;
    color: lime;
}}
footer {{
    text-align: center;
    margin-top: 50px;
    font-size: 13px;
    color: #aaa;
}}
</style>
</head>
<body>
<div class="container">
    <header>
        <h1>ZAKI DEV</h1>
        <p>Multi Services Platform</p>
    </header>
    <div class="services">

        <!-- 🎵 Music -->
        <div class="card">
            <h2>🎵 تحميل أغاني</h2>
            <form method="post">
                <input type="hidden" name="service" value="music">
                <input type="text" name="music_url" placeholder="رابط الأغنية" required>
                <button type="submit">تحميل</button>
            </form>
        </div>

        <!-- 🎬 Video -->
        <div class="card">
            <h2>🎬 تحميل فيديوهات</h2>
            <form method="post">
                <input type="hidden" name="service" value="video">
                <input type="text" name="video_url" placeholder="رابط الفيديو" required>
                <button type="submit">تحميل</button>
            </form>
        </div>

        <!-- 🤖 Bot -->
        <div class="card">
            <h2>🤖 تفعيل البوت</h2>
            <form method="post">
                <input type="hidden" name="service" value="bot">
                <input type="text" name="name" placeholder="اسمك داخل اللعبة" required>
                <input type="text" name="ff_id" placeholder="Free Fire ID" required>
                <button type="submit">تفعيل</button>
            </form>
        </div>

    </div>
    <div class="message">{message}</div>
    <footer>
        © 2026 ZAKI DEV • Legendary Services
    </footer>
</div>
</body>
</html>
'''

if __name__ == "__main__":
    app.run(debug=True)